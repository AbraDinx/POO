
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LMC I- Alumno
 */
public class CrearUsuarios {
    public static void main(String[] args) {
        AccesoArchivo.vaciarArchivo("usuarios.txt");
        Usuario u = new Usuario("Abraham Abila Antena", "Abraham", encriptar("pedrosanchez1"));
        AccesoArchivo.appendArchivo("usuarios.txt", u);
        u = new Usuario("Ruben Amorin Reyes Meza", "Piripipi", encriptar("Abraham123"));
        AccesoArchivo.appendArchivo("usuarios.txt", u);
        u = new Usuario("BOTASO DE FUEGO", "test", encriptar("test1234"));
        AccesoArchivo.appendArchivo("usuarios.txt", u);
        u = new Usuario("Patricia Vega Flores", "Paty", encriptar("paty123"));
        AccesoArchivo.appendArchivo("usuarios.txt", u);
    }
    
    public static String encriptar(String pass){
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(pass.getBytes(StandardCharsets.UTF_8));
            
            return HexFormat.of().formatHex(hash); 
        } catch (NoSuchAlgorithmException e) {
            System.out.println("ERROR: EL ALGORITMO DE ENCRIPCION NO FUE ACEPTADO!!");
            return null;
        }
    }
}

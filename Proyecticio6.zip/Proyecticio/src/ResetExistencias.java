/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vic
 */
public class ResetExistencias {
    public static void main(String[] args) {
        AccesoArchivo.vaciarArchivo("prestamos.txt");
    }
}


import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vic //String head;
 */
public class AccesoArchivo {
    public static ArrayList<Object> leerArchivo(String ruta) {
        /*
        String body = null;
        try {
            body = Files.readString(Path.of(ruta));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "No pudo leer el archivo", "ERROR:", JOptionPane.ERROR_MESSAGE);
        }
        ArrayList<String> lineas = new ArrayList<>(Arrays.asList(body.split("\n")));
        return lineas;
        */
        
        ArrayList<Object> lista = new ArrayList<>();
        File archivo = new File(ruta);
        if (!archivo.exists()) return lista;
        
        try (ObjectInputStream lector = new ObjectInputStream(new FileInputStream(archivo))){
            while (true) {
                lista.add(lector.readObject());
            }
        } catch (EOFException ignorable) {
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("ERROR EN LEER ARCHIVO!!! " + e);
        }
        return lista;
    }
    
    
    public static void appendArchivo(String ruta, Object objeto) {
        /*
        try {
            BufferedWriter editor = new BufferedWriter(new FileWriter(ruta));
            for (String linea : texto) {
                editor.write(linea);
                editor.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "No pudo modificar el archivo", "ERROR:", JOptionPane.ERROR_MESSAGE);
        }
        */
        
        ArrayList<Object> listaOld = leerArchivo(ruta);
        listaOld.add(objeto);
        try {
            ObjectOutputStream editor = new ObjectOutputStream(new FileOutputStream(ruta));
            for (Object o : listaOld) {
                editor.writeObject(o); 
            }
            editor.close();
        } catch (IOException e) {
            System.out.println("No pudo modificar el archivo" + e.getMessage());
        }
    }
    
    public static void vaciarArchivo(String ruta) {
        try {
            FileOutputStream desmenuzador = new FileOutputStream(ruta);
            desmenuzador.close();
        } catch (FileNotFoundException e){
            System.out.println("ERROR EN VACIAR ARCHIVO!!! Archivo no encontrado " + e.getMessage());
        } catch (IOException e){
            System.out.println("ERROR EN VACIAR ARCHIVO!!! Error de permisos" + e.getMessage());
        }
    }
    
    public static void editarExistencias(String ruta, int index, int nuevaCantidad) {
        ArrayList<Object> lista = leerArchivo(ruta);
        if (index >= 0 && index < lista.size()) { //Deberia ser redundante
            Object objeto = lista.get(index);
            if (objeto instanceof Libro) { //Deberia ser redundante
                Libro original = (Libro) objeto;
                Libro l = new Libro(original.getTitulo(), original.getAutor(), original.getPrecio(), original.getExistencias());
                l.setExistencias(nuevaCantidad);
                lista.set(index, l);
                vaciarArchivo(ruta);
                for (Object o : lista) {
                appendArchivo(ruta, o);
                }
            } else System.out.println("Intentaste editar con un Objeto nadaqueveriento, eso nada que ver");
        } else {
            System.out.println("ERROR, " + index + " no queda dentro del array");
        }
    }
}
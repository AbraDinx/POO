
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vic //String head;
 */
public class AccesoArchivo {
    public static ArrayList leerArchivo(String ruta) {
        String body = null;
        try {
            body = Files.readString(Path.of(ruta));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "No pudo leer el archivo", "ERROR:", JOptionPane.ERROR_MESSAGE);
        }
        ArrayList<String> lineas = new ArrayList<>(Arrays.asList(body.split("\n")));
        return lineas;
    }
    
    public static void appendArchivo(String ruta, ArrayList<String> texto) {
        try {
            BufferedWriter editor = new BufferedWriter(new FileWriter(ruta));
            for (String linea : texto) {
                //editor. CONTINUAAAAAAAAAAAAAAAAAAAAAAAA AQUOOOOOOOOOOOOOOOIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII..........................
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "No pudo modificar el archivo", "ERROR:", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
}